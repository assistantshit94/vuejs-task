<template>
 
  <div>
    <div v-if="loading">Loading...</div>
    <div v-if="error">{{ error }}</div>
  </div>

  <div>

    <table>
      <thead>
        <tr>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Salary</th>
          <th>Age</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="employee in employees" :key="employee.id">
          <td>{{ employee.firstName }}</td>
          <td>{{ employee.lastName }}</td>
          <td>{{ employee.salary }}</td>
          <td>{{ employee.age }}</td>
        </tr>
      </tbody>
    </table>
  </div>
  <div>
    <label for="filterBy">
      Filter By:
    </label>
    <select v-model="filterBy" id="filterBy">
      <option value="firstName">firstName</option>
      <option value="lastName">LastName</option>
      <option value="salary">Salary</option>
    </select>
    <label for="sortDirection">Sort:
      <select v-model="sortDirection" id="sortDirection">
        <option value="asc">Ascending</option>
        <option value="desc">Descending</option>
      </select>
      <input v-model="SearchQuery" type="text" placeholder="Search by First or Last Name">
    </label>
  </div>

  <table>
    <thread>
      <tr>
        <th @click="sortEmployees('firstName')">First Name</th>
        <th @click="sortEmployees('lastName')">Last Name</th>
        <th @click="sortEmployees('salary')">Salary</th>
        <th>Age</th>
        <th>Action</th>

      </tr>
    </thread>
    <tbody>
      <tr v-for="employee in filteredEmployees" :key="employee.id">
        <td>{{ employee.firstName }}</td>
        <td>{{ employee.lastName }}</td>
        <td>{{ employee.salary }}</td>
        <td>{{ employee.age }}</td>
      </tr>
      <td>
        <button @click="deleteEmployee(employee.id)">Delete Employee</button>
      </td>
    </tbody>
  </table>

  <div>
    <h2>Add Employee</h2>
    <form @submit.prevent="addEmployee">
      <label for="firstName"> First Name

      </label>
      <input v-model="newEmployee.firstName" type="text" id="firstName">
      <label for="lastName">Last Name

</label>
<input v-model="newEmployee.salary" type="text" id="salary">
<label for="salary"> Salary

</label>
<input v-model="newEmployee.age" type="text" id="age">
<label for="age"> Age

</label>
<input v-model="newEmployee.age" type="text" id="age">

    </form>
  </div>
</template>

<script>


export default {
  // name: 'App',
  // components: {
  //   HelyloWorld
  // }
  data() {

    return {
      employees: [],
      loading: true,
      error: null,
      filterBy: 'firstName',
      sortDirection: 'asc',
      SearchQuery: '',
      newEmployee:{
        firstName:'',
        lastName:'',
        salary:'',
        age:''
      }

    };
  },

  props: {
    employee: {

      type: Array,
      required: true
    }
  },
  created() {
    this.fetchEmployees();

  },
  computed:{
    filteredEmployees(){
      return this.employees.filter(employee=>{
        const search =this.SearchQuery.toLocaleLowerCase();
        return employee.firstName.toLocaleLowerCase.includes(search) ||
        employee.lastName.toLocaleLowerCase().includes(search);
      })
      // .sort((a,b)=>{
      //   const field = this. filterBy;
      //   const sortDirection = this. sortDirection=== 'asc'? 'asc':'desc';
      // })
    }
  },
  methods: {

    fetchEmployees() {
      fetch('https://dummy.restapiexample.com/api/v1/employees')
        .then(response => {
          if (!response.ok) {
            throw new Error('fail to fetch employees.');

          }
          return response.json();
        })
        .then(data => {
          this.employees = data;
          this.loading = false;
        })
        .catch(error => {
          this.loading = false;
          this.error = error.message;
        });
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
